# Calculadora
Elaborar una calculadora que resuelva las operaciones básicas matemáticas junto con las operaciones trigonométricas mas usadas
