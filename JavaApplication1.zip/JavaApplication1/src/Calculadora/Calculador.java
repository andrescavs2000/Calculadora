
package Calculadora;

/**
 *
 * @author gisel
 */
public class Calculador {
    float operando1;
    float operando2;
    float resultado;
    
    void Sumar(){
        resultado=operando1+operando2;
    }
    void Restar(){
        resultado=operando1-operando2;
    }
    void Multiplicar(){
        resultado=operando1*operando2;
    }
    void Dividir(){
          resultado=operando1/operando2;        
    }    
}
